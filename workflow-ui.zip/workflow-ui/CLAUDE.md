# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Network topology visualization web application built with React and AntV G6 graph library. Users can create canvases to visualize network topologies (BGP, OSPF, IS-IS protocols) and manage NIC parser tasks.

## Development Commands

- `npm run dev` - Start Vite development server
- `npm run build` - Build for production
- `npm run lint` - Run ESLint
- `npm run preview` - Preview production build locally

## Architecture

### Project Structure

- `src/main.jsx` - Application entry point; renders providers (TaskProvider, ToastProvider) wrapped around App
- `src/App.jsx` - React Router configuration with two routes: `/` (Overview) and `/canvas/:canvasId` (Canvas)
- `src/pages/` - Page-level components (Overview, Canvas)
- `src/components/` - Reusable modal components (CreateCanvasModal, CreateNicTaskModal, ViewTasksModal)
- `src/contexts/` - React Context providers for global state
- `src/utils/g6Config.js` - AntV G6 custom node registration
- `src/data/topologyData.js` - Static topology datasets

### Global State (React Context)

The application uses two global context providers that wrap the app in `main.jsx`:

1. **TaskContext** - Manages NIC parser tasks with states: pending, running, completed, failed. Provides CRUD operations and progress tracking.
2. **ToastContext** - Notification system for displaying alerts and messages.

### Graph Visualization (AntV G6)

The canvas uses AntV G6 for graph visualization. Custom nodes are registered via `G6.registerNode('device-node', ...)` in `utils/g6Config.js`. The graph uses force layout and supports zoom, drag-canvas, drag-node interactions. Event handling is set up for `node:click`, `edge:click`, and `canvas:click`.

### Data Persistence

Canvas data is persisted in `localStorage` under the key `network-canvases`. A default canvas is created on first load when storage is empty.

### Canvas Layout

The Canvas page uses a three-panel layout:
- Left sidebar: Topology tree navigation
- Center: Graph visualization container
- Right sidebar: Selected element properties

### CSS Patterns

Components use co-located CSS files with BEM-like naming. The color scheme follows Ant Design patterns (#1890ff primary, #52c41a success, #ff4d4f danger).