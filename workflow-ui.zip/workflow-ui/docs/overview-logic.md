# 总览页面操作逻辑说明

## 概述

总览页面（Overview）是应用的主页面，路由路径为 `/`。该页面展示了所有网络拓扑画布（Canvas）列表，并提供画布管理、解析任务创建等功能入口。

---

## 页面初始加载逻辑

### 1. 数据初始化（useEffect 钩子）

当组件挂载时（`useEffect` 空依赖数组），执行以下逻辑：

| 存储状态 | 操作 |
|---------|------|
| `localStorage` 中存在 `network-canvases` | 从存储读取并解析为 JSON，设置到 `canvases` 状态 |
| `localStorage` 中不存在数据 | 创建初始默认画布并存储 |

### 2. 默认画布结构

初始化时创建的默认画布包含以下字段：

```javascript
{
  id: 1,
  name: '网络拓扑测试画布',
  description: '包含BGP、OSPF、IS-IS三种协议的测试拓扑',
  createdAt: new Date().toISOString(),
  topologies: ['topology-bgp.json', 'topology-ospf.json', 'topology-isis.json']
}
```

---

## 页面结构

### 顶部操作栏

| 按钮 | 功能 | 点击行为 |
|-----|------|---------|
| 查看解析任务 | 打开解析任务列表弹窗 | `setShowTasksModal(true)` |
| 创建NIC文件解析任务 | 打开创建解析任务表单弹窗 | `setShowNicModal(true)` |
| 清除缓存 | 清除所有localStorage数据并刷新页面 | 弹窗确认后执行 `localStorage.clear()` 和 `window.location.reload()` |

### 画布列表区域

列表展示所有存储的 Canvas，每个 Canvas 卡片包含：
- 画布名称（`canvas.name`）
- 画布描述（`canvas.description`）
- 创建时间（格式化为中文日期）
- 拓扑数量（`canvas.topologies?.length || 0`）

#### 卡片点击行为

点击任意 Canvas 卡片，通过 `react-router-dom` 的 `navigate` 跳转到对应的画布详情页：
```
/canvas/:canvasId
```

#### 新建画布卡片

底部有一个特殊的"新建画布"卡片，点击后打开创建 Canvas 弹窗（`setShowModal(true)`）。

---

## 创建 Canvas 弹窗（CreateCanvasModal）

### 弹窗触发

点击"新建画布"卡片 -> `setShowModal(true)` -> 渲染 `CreateCanvasModal` 组件

### 弹窗关闭方式

1. 点击遮罩层（`modal-overlay`）
2. 点击"×"关闭按钮
3. 任一操作按钮点击后内部调用 `onClose`

### 三个创建选项页签

| 页签 | 状态值 | 功能描述 |
|-----|--------|---------|
| 从Canvas镜像创建 | `mirror` | 从预定义的镜像画布列表中选择并创建 |
| 创建空Canvas | `empty` | 创建一个不包含拓扑数据的空白画布 |
| 从命令行创建 | `command` | 暂未实现，显示占位提示 |

#### 页签 1：从Canvas镜像创建

**可用的镜像数据（MIRROR_CANVASES）：**
- ID 1: "网络拓扑测试画布" - 包含BGP、OSPF、IS-IS三种协议的测试拓扑
- ID 2: "上海数据中心网络" - 上海局点数据中心网络拓扑

**过滤功能（可选）：**
- 用户名称过滤
- 局点名称过滤
- 创建时间过滤

**镜像选择：**
- 单选框选择镜像 Canvas
- 显示镜像详情：名称、描述、创建者、局点、创建时间、拓扑数量

**操作按钮：**
- 取消 - 关闭弹窗
- 创建并进入 - 创建后跳转到画布详情（`handleCreateAndEnter`，当前未实现）
- 创建Canvas - 创建画布（`handleCreate`，仅显示 Toast 成功提示）

> **注意**：当前 `handleCreate` 和 `handleCreateAndEnter` 未实际创建数据或跳转，仅显示提示。

#### 页签 2：创建空Canvas

**表单字段：**
- Canvas名称（��填）- 文本输入
- 局点 - 下拉选择（北京局点、上海局点、广州局点、深圳局点）
- 非局点数据 - 复选框

**操作按钮：**
- 取消 - 关闭弹窗
- 创建Canvas - 创建画布（`handleCreate`，未实现）

#### 页签 3：从命令行创建

显示暂未实现提示。

---

## 创建 NIC 文件解析任务弹窗（CreateNicTaskModal）

### 弹窗触发

点击"创建NIC文件解析任务"按钮 -> `setShowNicModal(true)` -> 渲染 `CreateNicTaskModal` 组件

### 表单字段

| 字段 | 类型 | 必填 | 说明 |
|-----|------|-----|------|
| Canvas名称 | 文本输入 | 是 | 输入画布名称 |
| 局点 | 下拉选择 | 是 | 可选：北京局点、上海局点、广州局点、深圳局点 |
| NIC文件 | 多选列表 | 是 | 勾选需要解析的 NIC 文件 |

### NIC 文件列表

预定义的12个 NIC 文件（`ALL_NIC_FILES`）：
- Core-Router-01.nic, Core-Router-02.nic
- Edge-Switch-01.nic, Edge-Switch-02.nic
- Datacenter-Switch-01.nic, Datacenter-Switch-02.nic
- Border-Router-01.nic, Border-Router-02.nic
- Access-Switch-01.nic, Access-Switch-02.nic
- Firewall-Cluster-01.nic
- Load-Balancer-01.nic

### 全选/反选操作

| 操作 | 条件 | 行为 |
|-----|------|-----|
| 全选 | 不是全部选中时 | 选中所有 NIC 文件 |
| 反选 | 有选中文件时 | 清空所有选中 |

### 表单提交验证

提交前检查以下条件：
1. Canvas 名称非空（`canvasName.trim()`）
2. 已选择局点（`selectedSite` 非空）
3. 至少选择一个 NIC 文件（`selectedNicFiles.length > 0`）

### 提交成功后行为

1. 调用 `addTask(taskData)` 添加任务到全局任务上下文
2. 调用 `setShowNicModal(false)` 关闭弹窗
3. 调用 `showToast('NIC解析任务已提交：{canvasName}', 'success')` 显示成功提示

### 提交数据结构

```javascript
{
  canvasName: canvasName.trim(),
  siteId: selectedSite,
  nicFileIds: selectedNicFiles
}
```

---

## 查看解析任务弹窗（ViewTasksModal）

### 弹窗触发

点击"查看解析任务"按钮 -> `setShowTasksModal(true)` -> 渲染 `ViewTasksModal` 组件

### 任务筛选

顶部提供5个筛选按钮，显示对应状态的任务数量：

| 筛选项 | 状态 | 显示数量 |
|-------|------|---------|
| 全部 | `all` | `tasks.length` |
| 等待中 | `pending` | 等待中的任务数 |
| 运行中 | `running` | 运行中的任务数 |
| 已完成 | `completed` | 已完成的任务数 |
| 失败 | `failed` | 失败的任务数 |

点击不同筛选按钮，`filter` 状态更新，列表重新渲染对应状态的任务。

### 任务状态样式

| 状态 | 颜色 | 标签 |
|-----|------|------|
| pending | #faad14（黄色） | 等待中 |
| running | #1890ff（蓝色） | 运行中 |
| completed | #52c41a（绿色） | 已完成 |
| failed | #ff4d4f（红色） | 失败 |

### 任务列表项显示内容

每个任务卡片显示：

| 字段 | 显示内容 |
|-----|---------|
| 任务名称 | `task.name` |
| 任务状态 | 彩色标签 |
| 创建时间 | `task.createdAt` 格式化为中文日期时间 |
| Canvas | `task.canvasName` |
| 局点 | `task.siteName` |
| NIC文件 | `task.nicFileCount` 个 |

### 按状态显示的额外信息

| 状态 | 额外显示信息 |
|-----|-------------|
| `running` | 进度条 + 进度百分比/消息（`task.progress` + `task.progressMessage`） |
| `failed` | 错误信息（`task.errorMessage`） |
| `completed` | 完成耗时（秒）= `(completedAt - createdAt) / 1000` |

### 空状态

当筛选结果为空时，显示"暂无任务"提示。

---

## 全局上下文集成

### ToastContext

用于显示操作反馈提示，3秒后自动消失。

在Overview中使用的 Toast 场景：
- 创建NIC任务成功：显示 "NIC解析任务已提交：{canvasName}"

### TaskContext

提供全局任务管理能力：
- `addTask(taskData)` - 添加新任务
- `tasks` - 获取所有任务列表

任务数据由全局维护，可在不同组件间共享。

---

## 本地存储操作

### 读取

```javascript
localStorage.getItem('network-canvases')
```

### 写入

```javascript
localStorage.setItem('network-canvases', JSON.stringify(updatedCanvases))
```

### 清除

```javascript
localStorage.clear()
```

---

## 导航逻辑

使用 `react-router-dom` 的 `useNavigate` hook：

| 目标 | 路径 |
|-----|------|
| Canvas详情页 | `/canvas/:canvasId` |

点击 Canvas 卡片后执行：
```javascript
navigate(`/canvas/${canvas.id}`)
```

---

## 状态管理总结

| 状态 | 类型 | 作用 |
|-----|------|-----|
| `canvases` | 数组 | 存储所有 Canvas 数据 |
| `showModal` | 布尔 | 控制 CreateCanvasModal 显示 |
| `showNicModal` | 布尔 | 控制 CreateNicTaskModal 显示 |
| `showTasksModal` | 布尔 | 控制 ViewTasksModal 显示 |

---

## 页面交互流程图

```
用户进入页面
    |
    v
读取 localStorage
    |
    +-- 有数据 --> 显示 Canvas 列表
    |
    +-- 无数据 --> 创建默认画布并写入 localStorage
                    |
                    v
                显示 Canvas 列表
```

### 画布操作流程

```
用户点击 Canvas 卡片 --> 跳转到 /canvas/:canvasId
用户点击新建画布 --> 打开创建弹窗 --> 填写信息 --> 创建 Canvas
```

### 任务操作流程

```
创建任务 --> 打开任务创建弹窗 --> 填写表单 --> 提交 --> 添加到全局任务列表 + Toast提示
查看任务 --> 打开任务列表弹窗 --> 筛选查看不同状态的任务
```