import { register, BaseNode } from '@antv/g6'
import { Circle as GCircle } from '@antv/g'

/**
 * 设备角色对应的样式配置
 */
const DEVICE_STYLES = {
  core: {
    size: 60,
    stroke: '#52c41a',
    strokeWidth: 4,
    haloColor: 'rgba(82, 196, 26, 0.3)',
    shadowColor: 'rgba(82, 196, 26, 0.4)',
    icon: '🌐',
    gradient: ['#52c41a', '#73d13d']
  },
  border: {
    size: 55,
    stroke: '#faad14',
    strokeWidth: 4,
    haloColor: 'rgba(250, 173, 20, 0.3)',
    shadowColor: 'rgba(250, 173, 20, 0.4)',
    icon: '🚀',
    gradient: ['#faad14', '#ffc53d']
  },
  edge: {
    size: 48,
    stroke: '#1890ff',
    strokeWidth: 3,
    haloColor: 'rgba(24, 144, 255, 0.25)',
    shadowColor: 'rgba(24, 144, 255, 0.3)',
    icon: '🔌',
    gradient: ['#1890ff', '#40a9ff']
  },
  branch: {
    size: 45,
    stroke: '#722ed1',
    strokeWidth: 3,
    haloColor: 'rgba(114, 46, 209, 0.25)',
    shadowColor: 'rgba(114, 46, 209, 0.3)',
    icon: '📡',
    gradient: ['#722ed1', '#9254de']
  },
  access: {
    size: 40,
    stroke: '#13c2c2',
    strokeWidth: 2,
    haloColor: 'rgba(19, 194, 194, 0.2)',
    shadowColor: 'rgba(19, 194, 194, 0.25)',
    icon: '💻',
    gradient: ['#13c2c2', '#36cfc9']
  },
  firewall: {
    size: 52,
    stroke: '#ff4d4f',
    strokeWidth: 3,
    haloColor: 'rgba(255, 77, 79, 0.3)',
    shadowColor: 'rgba(255, 77, 79, 0.4)',
    icon: '🛡️',
    gradient: ['#ff4d4f', '#ff7875']
  },
  spine: {
    size: 50,
    stroke: '#eb2f96',
    strokeWidth: 3,
    haloColor: 'rgba(235, 47, 150, 0.3)',
    shadowColor: 'rgba(235, 47, 150, 0.35)',
    icon: '🔗',
    gradient: ['#eb2f96', '#f759ab']
  },
  leaf: {
    size: 42,
    stroke: '#1890ff',
    strokeWidth: 2,
    haloColor: 'rgba(24, 144, 255, 0.2)',
    shadowColor: 'rgba(24, 144, 255, 0.25)',
    icon: '🍃',
    gradient: ['#1890ff', '#69c0ff']
  },
  aggregation: {
    size: 48,
    stroke: '#fa541c',
    strokeWidth: 3,
    haloColor: 'rgba(250, 84, 28, 0.3)',
    shadowColor: 'rgba(250, 84, 28, 0.35)',
    icon: '🔶',
    gradient: ['#fa541c', '#ff7a45']
  },
  loadbalancer: {
    size: 48,
    stroke: '#fadb14',
    strokeWidth: 3,
    haloColor: 'rgba(250, 219, 20, 0.3)',
    shadowColor: 'rgba(250, 219, 20, 0.35)',
    icon: '⚖️',
    gradient: ['#fadb14', '#ffe58f']
  },
  management: {
    size: 38,
    stroke: '#8c8c8c',
    strokeWidth: 2,
    haloColor: 'rgba(140, 140, 140, 0.2)',
    shadowColor: 'rgba(140, 140, 140, 0.25)',
    icon: '⚙️',
    gradient: ['#8c8c8c', '#bfbfbf']
  },
  asbr: {
    size: 52,
    stroke: '#a0d911',
    strokeWidth: 4,
    haloColor: 'rgba(160, 217, 17, 0.3)',
    shadowColor: 'rgba(160, 217, 17, 0.4)',
    icon: '🔄',
    gradient: ['#a0d911', '#b7eb8f']
  },
  default: {
    size: 44,
    stroke: '#1890ff',
    strokeWidth: 3,
    haloColor: 'rgba(24, 144, 255, 0.25)',
    shadowColor: 'rgba(24, 144, 255, 0.3)',
    icon: '📦',
    gradient: ['#1890ff', '#40a9ff']
  }
}

/**
 * 自定义设备节点 - 适用于 G6 v5
 * 具有现代感的网络设备节点，带渐变、阴影、光晕效果
 */
class DeviceNode extends BaseNode {
  constructor(options) {
    super(options)
    this.type = 'device-node'
  }

  // 获取设备角色的样式配置
  getDeviceStyle(role, color) {
    if (role && DEVICE_STYLES[role]) {
      return DEVICE_STYLES[role]
    }
    // 使用颜色创建默认样式
    return {
      ...DEVICE_STYLES.default,
      stroke: color || DEVICE_STYLES.default.stroke,
      gradient: [color || '#1890ff', this.lightenColor(color || '#1890ff', 20)]
    }
  }

  // 颜色变亮函数
  lightenColor(color, percent) {
    const num = parseInt(color.replace('#', ''), 16)
    const amt = Math.round(2.55 * percent)
    const R = (num >> 16) + amt
    const G = (num >> 8 & 0x00FF) + amt
    const B = (num & 0x0000FF) + amt
    return '#' + (0x1000000 +
      (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
      (G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
      (B < 255 ? (B < 1 ? 0 : B) : 255)
    ).toString(16).slice(1)
  }

  drawKeyShape(attributes, container) {
    const { role, color } = attributes
    const style = this.getDeviceStyle(role, color)
    const size = this.getSize(attributes)
    const radius = Math.min(...size) / 2

    // 创建渐变圆形主形状
    return this.upsert('key', GCircle, {
      r: radius - 4,
      fill: color || style.gradient[0],
      stroke: style.stroke,
      lineWidth: style.strokeWidth,
      shadowColor: style.shadowColor,
      shadowBlur: 12,
      shadowOffsetX: 0,
      shadowOffsetY: 4
    }, container)
  }

  // 绘制光晕效果
  drawHalo(attributes, container) {
    const { halo } = attributes
    if (halo === false) return

    const size = this.getSize(attributes)
    const radius = Math.min(...size) / 2
    const { role } = attributes
    const style = this.getDeviceStyle(role)

    this.upsert('halo', GCircle, {
      r: radius + 6,
      fill: style.haloColor,
      stroke: 'transparent'
    }, container)
  }

  drawIconShape(attributes, container) {
    const { icon, role, iconText } = attributes
    const size = this.getSize(attributes)
    const style = this.getDeviceStyle(role)

    // 获取图标文本处理
    let finalIconText = ''

    // 优先使用 iconText 属性 (G6 v5 标准属性)
    if (iconText && typeof iconText === 'string') {
      finalIconText = iconText
    }
    // 如果有传入 icon 且不是布尔值，使用传入的 icon
    else if (icon && typeof icon !== 'boolean') {
      finalIconText = String(icon)
    }
    // 否则使用角色的默认图标
    else {
      finalIconText = style.icon || '📦'
    }

    // 过滤掉无效值
    if (!finalIconText || finalIconText === 'true' || finalIconText === 'false' || finalIconText.length > 10) {
      finalIconText = style.icon || '📦'
    }

    return {
      text: finalIconText,
      fontSize: Math.min(...size) * 0.45,
      textAlign: 'center',
      textBaseline: 'middle',
      fill: '#fff',
      fontWeight: '500'
    }
  }

  getLabelStyle(attributes) {
    const { label } = attributes

    // 如果没有标签，返回 false 不显示
    if (label === false || !label) return false

    const size = this.getSize(attributes)
    const radius = Math.min(...size) / 2

    // 确保 label 是字符串
    const labelText = String(label)

    return {
      text: labelText,
      fontSize: 13,
      textAlign: 'center',
      fill: '#1f2937',
      fontWeight: '600',
      offsetY: radius + 18,
      backgroundFill: 'rgba(255, 255, 255, 0.9)',
      backgroundPadding: [4, 8],
      backgroundRadius: 8,
      stroke: '#e5e7eb',
      lineWidth: 1
    }
  }
}

export function registerDeviceNode() {
  register('node', 'device-node', DeviceNode)
}