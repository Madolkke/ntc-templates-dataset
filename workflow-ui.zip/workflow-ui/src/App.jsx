import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Overview from './pages/Overview'
import Canvas from './pages/Canvas'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Overview />} />
        <Route path="/canvas/:canvasId" element={<Canvas />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App