import { useEffect, useRef, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Graph } from '@antv/g6'
import { NodeEvent, EdgeEvent, CanvasEvent } from '@antv/g6'
import { registerDeviceNode } from '../utils/g6Config'
import TOPOLOGY_DATA from '../data/topologyData'
import './Canvas.css'

// 标记节点是否已注册，避免重复注册警告
let isNodeRegistered = false

export default function Canvas() {
  const { canvasId } = useParams()
  const navigate = useNavigate()
  const graphRef = useRef(null)
  const containerRef = useRef(null)
  const selectedNodeId = useRef(null)
  const selectedEdgeId = useRef(null)
  const [selectedTopology, setSelectedTopology] = useState(null)
  const [selectedElement, setSelectedElement] = useState(null)

  useEffect(() => {
    if (!containerRef.current) return

    // 只注册一次自定义节点
    if (!isNodeRegistered) {
      registerDeviceNode()
      isNodeRegistered = true
    }

    graphRef.current = new Graph({
      container: 'graph-container',
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      animation: false,
      behaviors: [
        { type: 'drag-canvas', enableOptimize: true },
        { type: 'zoom-canvas', sensitivity: 1, enableOptimize: true, modifier: 'ctrl' },
        { type: 'drag-element', enableOptimize: true, cursor: 'grab' }
      ],
      layout: {
        type: 'circular',
        radius: 200,
        preventOverlap: true,
        nodeSpacing: 50,
        linkDistance: 120
      },
      node: {
        type: 'device-node',
        halo: false,
        style: {
          cursor: 'pointer'
        }
      },
      edge: {
        type: 'cubic-horizontal',
        style: {
          stroke: '#c9cdd4',
          lineWidth: 2,
          endArrow: {
            path: 'M 0,0 L 10,5 L 0,10 Z',
            fill: '#c9cdd4',
            d: 10
          },
          radius: 10
        }
      }
    })

    const handleResize = () => {
      if (graphRef.current) {
        graphRef.current.resize()
      }
    }

    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      if (graphRef.current) {
        graphRef.current.destroy()
      }
    }
  }, [])

  const handleTopologySelect = async (topologyKey) => {
    const topology = TOPOLOGY_DATA[topologyKey]
    if (!topology || !graphRef.current) return

    setSelectedTopology(topology)
    setSelectedElement(null)
    selectedNodeId.current = null
    selectedEdgeId.current = null

    // 销毁旧实例并重新创建
    if (graphRef.current) {
      graphRef.current.destroy()
    }

    // 等待 DOM 更新后再创建新实例
    setTimeout(async () => {
      if (!containerRef.current) return

      // 根据角色获取节点大小
      const getNodeSize = (role) => {
        const sizes = { core: 70, border: 65, spine: 60, leaf: 50, asbr: 60, default: 55 }
        return sizes[role] || sizes.default
      }

      graphRef.current = new Graph({
        container: 'graph-container',
        width: containerRef.current.clientWidth,
        height: containerRef.current.clientHeight,
        animation: true,
        animationDuration: 500,
        behaviors: [
          { type: 'drag-canvas', enableOptimize: true },
          { type: 'zoom-canvas', sensitivity: 1.2, enableOptimize: true, modifier: 'ctrl' },
          { type: 'drag-element', enableOptimize: true, cursor: 'grab' }
        ],
        layout: {
          type: 'circular',
          radius: 250,
          preventOverlap: true,
          nodeSpacing: 30
        },
        node: {
          type: 'device-node',
          halo: false,
          style: {
            cursor: 'pointer'
          },
          state: {
            selected: {
              halo: true,
              lineWidth: 4
            },
            hover: {
              halo: true,
              lineWidth: 3,
              opacity: 0.9
            }
          }
        },
        edge: {
          type: 'cubic',
          style: {
            stroke: '#94a3b8',
            lineWidth: 2,
            opacity: 0.8,
            endArrow: {
              path: 'M 0,0 L 12,6 L 0,12 Z',
              fill: '#94a3b8',
              d: 12
            },
            radius: 20
          },
          state: {
            selected: {
              stroke: '#1890ff',
              lineWidth: 3,
              endArrow: {
                path: 'M 0,0 L 12,6 L 0,12 Z',
                fill: '#1890ff',
                d: 12
              }
            },
            hover: {
              stroke: '#40a9ff',
              lineWidth: 2.5
            }
          }
        }
      })

      const nodes = topology.nodes.map(node => ({
        id: node.id,
        label: node.label,
        iconText: node.icon, // G6 v5 uses iconText for text icons
        iconColor: '#fff',
        role: node.role,
        color: node.color,
        size: getNodeSize(node.role),
        halo: false
      }))

      const edges = topology.edges.map((edge, index) => ({
        source: edge.source,
        target: edge.target,
        id: `edge-${index}`
      }))

      // 使用 G6 v5 的 setData API
      graphRef.current.setData({ nodes, edges })
      await graphRef.current.render()
      await graphRef.current.fitView(40)

      // 重新监听事件
      graphRef.current.on(NodeEvent.CLICK, (evt) => {
        const node = evt.target
        const data = node.getData()
        setSelectedElement({
          type: 'node',
          data: data
        })

        // 清除之前的选中状态
        if (selectedNodeId.current) {
          graphRef.current.setElementState({ [selectedNodeId.current]: [] })
        }
        if (selectedEdgeId.current) {
          graphRef.current.setElementState({ [selectedEdgeId.current]: [] })
        }

        // 设置新的选中状态
        selectedNodeId.current = data.id
        graphRef.current.setElementState({ [data.id]: 'selected' })
      })

      graphRef.current.on(EdgeEvent.CLICK, (evt) => {
        const edge = evt.target
        const data = edge.getData()
        setSelectedElement({
          type: 'edge',
          data: data
        })

        // 清除之前的选中状态
        if (selectedNodeId.current) {
          graphRef.current.setElementState({ [selectedNodeId.current]: [] })
        }
        if (selectedEdgeId.current) {
          graphRef.current.setElementState({ [selectedEdgeId.current]: [] })
        }

        // 设置新的选中状态
        selectedEdgeId.current = data.id
        graphRef.current.setElementState({ [data.id]: 'selected' })
      })

      graphRef.current.on(CanvasEvent.CLICK, (evt) => {
        setSelectedElement(null)

        // 清除所有选中状态
        if (selectedNodeId.current) {
          graphRef.current.setElementState({ [selectedNodeId.current]: [] })
          selectedNodeId.current = null
        }
        if (selectedEdgeId.current) {
          graphRef.current.setElementState({ [selectedEdgeId.current]: [] })
          selectedEdgeId.current = null
        }
      })
    }, 0)
  }

  const handleBack = () => {
    navigate('/')
  }

  return (
    <div className="canvas">
      <div className="canvas-topbar">
        <div className="topbar-left">
          <button className="topbar-btn btn-back" onClick={handleBack}>← 返回</button>
          <span className="canvas-title">网络拓扑可视化</span>
        </div>
        <div className="topbar-right">
          <button
            className="topbar-btn btn-zoom-in"
            onClick={() => graphRef.current?.zoomBy(1.2)}
          >
            放大
          </button>
          <button
            className="topbar-btn btn-zoom-out"
            onClick={() => graphRef.current?.zoomBy(0.8)}
          >
            缩小
          </button>
          <button
            className="topbar-btn btn-fit"
            onClick={() => graphRef.current?.fitView(40)}
          >
            适应画布
          </button>
          <button
            className="topbar-btn btn-layout"
            onClick={() => {
              if (graphRef.current) {
                // 重新执行布局
                const layout = graphRef.current.getLayout()
                graphRef.current.setLayout({
                  ...layout,
                  type: layout.type
                })
              }
            }}
          >
            重新布局
          </button>
        </div>
      </div>

      <div className="canvas-body">
        <aside className="canvas-drawer">
          <div className="drawer-tabs">
            <button className="drawer-tab active">拓扑树</button>
            <button className="drawer-tab">图层</button>
            <button className="drawer-tab">过滤器</button>
          </div>
          <div className="drawer-content">
            <div className="topology-tree">
              <div className="tree-node tree-node-root">
                <div className="tree-node-header">
                  <span className="tree-node-icon">📁</span>
                  <span className="tree-node-name">网络拓扑测试画布</span>
                </div>
                <div className="tree-node-children">
                  <div
                    className={`tree-node ${selectedTopology?.id === 'bgp' ? 'selected' : ''}`}
                    onClick={() => handleTopologySelect('bgp')}
                  >
                    <div className="tree-node-header">
                      <span className="tree-node-icon">📊</span>
                      <span className="tree-node-name">BGP网络拓扑</span>
                      <span className="tree-node-meta">19 节点</span>
                    </div>
                  </div>
                  <div
                    className={`tree-node ${selectedTopology?.id === 'ospf' ? 'selected' : ''}`}
                    onClick={() => handleTopologySelect('ospf')}
                  >
                    <div className="tree-node-header">
                      <span className="tree-node-icon">📊</span>
                      <span className="tree-node-name">OSPF企业网络</span>
                      <span className="tree-node-meta">20 节点</span>
                    </div>
                  </div>
                  <div
                    className={`tree-node ${selectedTopology?.id === 'isis' ? 'selected' : ''}`}
                    onClick={() => handleTopologySelect('isis')}
                  >
                    <div className="tree-node-header">
                      <span className="tree-node-icon">📊</span>
                      <span className="tree-node-name">IS-IS数据中心</span>
                      <span className="tree-node-meta">22 节点</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </aside>

        <main className="canvas-main">
          {selectedTopology ? (
            <div className="canvas-container" id="graph-container" ref={containerRef} />
          ) : (
            <div className="canvas-container" id="graph-container" ref={containerRef}>
              <div className="graph-placeholder">
                <div className="placeholder-icon">🌐</div>
                <div className="placeholder-text">请从左侧拓扑树选择一个拓扑</div>
              </div>
            </div>
          )}
        </main>

        <aside className="canvas-panel">
          <div className="panel-header">属性</div>
          <div className="panel-content">
            {selectedElement ? (
              <div className="panel-details">
                <div className="detail-section">
                  <div className="detail-title">{selectedElement.type === 'node' ? '设备信息' : '连接信息'}</div>
                  {selectedElement.type === 'node' ? (
                    <>
                      <div className="detail-item">
                        <span className="detail-label">ID:</span>
                        <span className="detail-value">{selectedElement.data.id}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">名称:</span>
                        <span className="detail-value">{selectedElement.data.label}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">角色:</span>
                        <span className="detail-value">{selectedElement.data.role}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">图标:</span>
                        <span className="detail-value">{selectedElement.data.icon}</span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="detail-item">
                        <span className="detail-label">ID:</span>
                        <span className="detail-value">{selectedElement.data.id}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">源节点:</span>
                        <span className="detail-value">{selectedElement.data.source}</span>
                      </div>
                      <div className="detail-item">
                        <span className="detail-label">目标节点:</span>
                        <span className="detail-value">{selectedElement.data.target}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            ) : (
              <div className="panel-empty">
                <div className="empty-icon">🔍</div>
                <div className="empty-text">请选择设备或连接</div>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  )
}