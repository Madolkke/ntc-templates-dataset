import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import CreateCanvasModal from '../components/CreateCanvasModal'
import CreateNicTaskModal from '../components/CreateNicTaskModal'
import ViewTasksModal from '../components/ViewTasksModal'
import { useToast } from '../contexts/ToastContext'
import { useTask } from '../contexts/TaskContext'
import './Overview.css'

export default function Overview() {
  const [canvases, setCanvases] = useState([])
  const [showModal, setShowModal] = useState(false)
  const [showNicModal, setShowNicModal] = useState(false)
  const [showTasksModal, setShowTasksModal] = useState(false)
  const showToast = useToast()
  const { addTask } = useTask()

  useEffect(() => {
    const saved = localStorage.getItem('network-canvases')
    if (saved) {
      setCanvases(JSON.parse(saved))
    } else {
      const initialCanvas = {
        id: 1,
        name: '网络拓扑测试画布',
        description: '包含BGP、OSPF、IS-IS三种协议的测试拓扑',
        createdAt: new Date().toISOString(),
        topologies: ['topology-bgp.json', 'topology-ospf.json', 'topology-isis.json']
      }
      setCanvases([initialCanvas])
      localStorage.setItem('network-canvases', JSON.stringify([initialCanvas]))
    }
  }, [])

  const handleCreateCanvas = (canvasData) => {
    const newCanvas = {
      id: canvases.length + 1,
      name: canvasData.name,
      description: canvasData.description,
      createdAt: new Date().toISOString(),
      topologies: []
    }
    const updated = [...canvases, newCanvas]
    setCanvases(updated)
    localStorage.setItem('network-canvases', JSON.stringify(updated))
    setShowModal(false)
  }

  const handleClearCache = () => {
    if (window.confirm('确定要清除所有缓存数据吗？这将重置为初始状态。')) {
      localStorage.clear()
      window.location.reload()
    }
  }

  const handleCreateNicTask = (taskData) => {
    addTask(taskData)
    setShowNicModal(false)
    showToast(`NIC解析任务已提交：${taskData.canvasName}`, 'success')
  }

  const navigate = useNavigate()

  return (
    <div className="overview">
      <header className="overview-header">
        <div className="header-content">
          <h1>网络拓扑可视化</h1>
          <div className="header-actions">
            <button className="header-btn btn-view-tasks" onClick={() => setShowTasksModal(true)}>
              查看解析任务
            </button>
            <button className="header-btn btn-create-nic" onClick={() => setShowNicModal(true)}>
              创建NIC文件解析任务
            </button>
            <button className="header-btn btn-clear-cache" onClick={handleClearCache}>
              清除缓存
            </button>
          </div>
        </div>
      </header>
      <main className="overview-main">
        <div className="canvas-grid">
          {canvases.map(canvas => (
            <div
              key={canvas.id}
              className="canvas-card"
              onClick={() => navigate(`/canvas/${canvas.id}`)}
            >
              <h3 className="canvas-name">{canvas.name}</h3>
              <p className="canvas-description">{canvas.description}</p>
              <div className="canvas-meta">
                <span className="canvas-date">
                  创建于 {new Date(canvas.createdAt).toLocaleDateString('zh-CN')}
                </span>
                <span className="canvas-topology-count">
                  {canvas.topologies?.length || 0} 个拓扑
                </span>
              </div>
            </div>
          ))}
          <div className="canvas-card add-canvas" onClick={() => setShowModal(true)}>
            <div className="add-icon">+</div>
            <span>新建画布</span>
          </div>
        </div>
      </main>
      {showModal && (
        <CreateCanvasModal onClose={() => setShowModal(false)} />
      )}
        {showNicModal && (
          <CreateNicTaskModal
            onClose={() => setShowNicModal(false)}
            onCreate={handleCreateNicTask}
          />
        )}
        {showTasksModal && (
          <ViewTasksModal
            onClose={() => setShowTasksModal(false)}
          />
        )}
      </div>
  )
}