import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import './contexts/ToastContext.css'
import App from './App.jsx'
import { ToastProvider } from './contexts/ToastContext'
import { TaskProvider } from './contexts/TaskContext'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <TaskProvider>
      <ToastProvider>
        <App />
      </ToastProvider>
    </TaskProvider>
  </React.StrictMode>,
)