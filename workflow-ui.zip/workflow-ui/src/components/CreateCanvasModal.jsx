import { useState } from 'react'
import { useToast } from '../contexts/ToastContext'
import './CreateCanvasModal.css'

const SITES = [
  { id: 'site1', name: '北京局点' },
  { id: 'site2', name: '上海局点' },
  { id: 'site3', name: '广州局点' },
  { id: 'site4', name: '深圳局点' }
]

const MIRROR_CANVASES = [
  {
    id: 1,
    name: '网络拓扑测试画布',
    description: '包含BGP、OSPF、IS-IS三种协议的测试拓扑',
    creator: 'admin',
    site: '北京局点',
    createdAt: '2026-02-01T10:30:00.000Z',
    topologyCount: 3
  },
  {
    id: 2,
    name: '上海数据中心网络',
    description: '上海局点数据中心网络拓扑',
    creator: 'zhangsan',
    site: '上海局点',
    createdAt: '2026-02-02T14:20:00.000Z',
    topologyCount: 2
  }
]

export default function CreateCanvasModal({ onClose }) {
  const [activeTab, setActiveTab] = useState('mirror')
  const [selectedMirrorId, setSelectedMirrorId] = useState(null)
  const showToast = useToast()

  const handleSelectMirror = (canvasId) => {
    setSelectedMirrorId(canvasId)
  }

  const handleCreate = () => {
    showToast('Canvas创建成功', 'success')
  }

  const handleCreateAndEnter = () => {
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content canvas-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">创建Canvas</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>

        <div className="tabs">
          <button 
            className={`tab-btn ${activeTab === 'mirror' ? 'active' : ''}`}
            onClick={() => setActiveTab('mirror')}
          >
            从Canvas镜像创建
          </button>
          <button 
            className={`tab-btn ${activeTab === 'empty' ? 'active' : ''}`}
            onClick={() => setActiveTab('empty')}
          >
            创建空Canvas
          </button>
          <button 
            className={`tab-btn ${activeTab === 'command' ? 'active' : ''}`}
            onClick={() => setActiveTab('command')}
          >
            从命令行创建
          </button>
        </div>

        <div className="tab-content">
          {activeTab === 'mirror' && (
            <div className="mirror-tab">
              <div className="form-group">
                <label className="form-label">Canvas名称</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="请输入Canvas名称"
                />
              </div>
              
              <div className="filterfilter-section">
                <div className="filter-section-title">
                  <span className="filter-title-icon">🔍</span>
                  <span>过滤条件（可选）</span>
                </div>
                <div className="form-group">
                  <label className="form-label">用户名称</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="请输入用户名称过滤"
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">局点名称</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="请输入局点名称过滤"
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">创建时间</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="请输入创建时间过滤"
                  />
                </div>
              </div>

              <div className="mirror-list">
                {MIRROR_CANVASES.map(canvas => (
                  <div 
                    key={canvas.id} 
                    className={`mirror-item ${selectedMirrorId === canvas.id ? 'selected' : ''}`}
                    onClick={() => handleSelectMirror(canvas.id)}
                  >
                    <div className="mirror-header">
                      <div className="mirror-header-left">
                        <input
                          type="radio"
                          name="mirror-select"
                          checked={selectedMirrorId === canvas.id}
                          onChange={() => handleSelectMirror(canvas.id)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        <span className="mirror-name">{canvas.name}</span>
                      </div>
                      <span className="mirror-topologies">{canvas.topologyCount} 个拓扑</span>
                    </div>
                    <div className="mirror-details">
                      <div className="mirror-detail-item">
                        <span className="mirror-label">描述:</span>
                        <span>{canvas.description}</span>
                      </div>
                      <div className="mirror-detail-item">
                        <span className="mirror-label">创建者:</span>
                        <span>{canvas.creator}</span>
                      </div>
                      <div className="mirror-detail-item">
                        <span className="mirror-label">局点:</span>
                        <span>{canvas.site}</span>
                      </div>
                      <div className="mirror-detail-item">
                        <span className="mirror-label">创建时间:</span>
                        <span>{new Date(canvas.createdAt).toLocaleString('zh-CN')}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="modal-actions">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={onClose}
                >
                  取消
                </button>
                <button 
                  type="button" 
                  className="btn btn-primary"
                  onClick={handleCreateAndEnter}
                  disabled={!selectedMirrorId}
                >
                  创建并进入
                </button>
                <button 
                  type="button" 
                  className="btn btn-primary"
                  onClick={handleCreate}
                  disabled={!selectedMirrorId}
                >
                  创建Canvas
                </button>
              </div>
            </div>
          )}

          {activeTab === 'empty' && (
            <div className="empty-tab">
              <div className="form-group">
                <label className="form-label">Canvas名称 *</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="请输入Canvas名称"
                />
              </div>

              <div className="form-group">
                <label className="form-label">局点</label>
                <select className="form-select">
                  <option value="">请选择局点</option>
                  {SITES.map(site => (
                    <option key={site.id} value={site.id}>{site.name}</option>
                  ))}
                </select>
              </div>

              <div className="form-group checkbox-group">
                <label className="checkbox-label">
                  <input type="checkbox" />
                  <span>非局点数据</span>
                </label>
              </div>

              <div className="modal-actions">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={onClose}
                >
                  取消
                </button>
                <button 
                  type="button" 
                  className="btn btn-primary"
                  onClick={handleCreate}
                >
                  创建Canvas
                </button>
              </div>
            </div>
          )}

          {activeTab === 'command' && (
            <div className="command-tab">
              <div className="command-empty">
                从命令行创建功能暂未实现
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}