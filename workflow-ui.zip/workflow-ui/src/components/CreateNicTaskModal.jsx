import { useState } from 'react'
import './CreateNicTaskModal.css'

const SITES = [
  { id: 'site1', name: '北京局点' },
  { id: 'site2', name: '上海局点' },
  { id: 'site3', name: '广州局点' },
  { id: 'site4', name: '深圳局点' }
]

const ALL_NIC_FILES = [
  { id: 'nic1', name: 'Core-Router-01.nic' },
  { id: 'nic2', name: 'Core-Router-02.nic' },
  { id: 'nic3', name: 'Edge-Switch-01.nic' },
  { id: 'nic4', name: 'Edge-Switch-02.nic' },
  { id: 'nic5', name: 'Datacenter-Switch-01.nic' },
  { id: 'nic6', name: 'Datacenter-Switch-02.nic' },
  { id: 'nic7', name: 'Border-Router-01.nic' },
  { id: 'nic8', name: 'Border-Router-02.nic' },
  { id: 'nic9', name: 'Access-Switch-01.nic' },
  { id: 'nic10', name: 'Access-Switch-02.nic' },
  { id: 'nic11', name: 'Firewall-Cluster-01.nic' },
  { id: 'nic12', name: 'Load-Balancer-01.nic' }
]

const SITE_MAP = {
  site1: '北京局点',
  site2: '上海局点',
  site3: '广州局点',
  site4: '深圳局点'
}

export default function CreateNicTaskModal({ onClose, onCreate }) {
  const [selectedSite, setSelectedSite] = useState('')
  const [canvasName, setCanvasName] = useState('')
  const [selectedNicFiles, setSelectedNicFiles] = useState([])

  const handleSiteChange = (siteId) => {
    setSelectedSite(siteId)
    setSelectedNicFiles([])
  }

  const handleNicFileToggle = (nicId) => {
    setSelectedNicFiles(prev =>
      prev.includes(nicId) ? prev.filter(id => id !== nicId) : [...prev, nicId]
    )
  }

  const handleSelectAll = () => {
    setSelectedNicFiles(ALL_NIC_FILES.map(f => f.id))
  }

  const handleDeselectAll = () => {
    setSelectedNicFiles([])
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (canvasName.trim() && selectedSite && selectedNicFiles.length > 0) {
      onCreate({
        canvasName: canvasName.trim(),
        siteId: selectedSite,
        nicFileIds: selectedNicFiles
      })
    }
  }

  const filteredNicFiles = ALL_NIC_FILES
  const allSelected = filteredNicFiles.length > 0 && 
    filteredNicFiles.every(f => selectedNicFiles.includes(f.id))

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content nic-modal-content" onClick={(e) => e.stopPropagation()}>
        <h2 className="modal-title">创建NIC文件解析任务</h2>
        <form className="modal-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Canvas名称 *</label>
            <input
              type="text"
              className="form-input"
              value={canvasName}
              onChange={(e) => setCanvasName(e.target.value)}
              placeholder="请输入Canvas名称"
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">局点 *</label>
            <select
              className="form-select"
              value={selectedSite}
              onChange={(e) => handleSiteChange(e.target.value)}
              required
            >
              <option value="">请选择局点</option>
              {SITES.map(site => (
                <option key={site.id} value={site.id}>{site.name}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">NIC文件 *</label>
            <div className="nic-files-container">
              <div className="nic-files-actions">
                <button
                  type="button"
                  className="btn-link"
                  onClick={handleSelectAll}
                  disabled={allSelected}
                >
                  全选
                </button>
                <button
                  type="button"
                  className="btn-link"
                  onClick={handleDeselectAll}
                  disabled={selectedNicFiles.length === 0}
                >
                  反选
                </button>
              </div>
              <div className="nic-files-list">
                {filteredNicFiles.map(nicFile => (
                  <label key={nicFile.id} className="nic-file-item">
                    <input
                      type="checkbox"
                      checked={selectedNicFiles.includes(nicFile.id)}
                      onChange={() => handleNicFileToggle(nicFile.id)}
                    />
                    <span>{nicFile.name}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
          <div className="modal-actions">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              取消
            </button>
            <button
              type="submit"
              className="btn btn-primary"
              disabled={!canvasName.trim() || selectedNicFiles.length === 0}
            >
              提交任务
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}