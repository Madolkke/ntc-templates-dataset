import { useState } from 'react'
import { useTask } from '../contexts/TaskContext'
import './ViewTasksModal.css'

export default function ViewTasksModal({ onClose }) {
  const { tasks } = useTask()
  const [filter, setFilter] = useState('all')

  const filteredTasks = filter === 'all' 
    ? tasks 
    : tasks.filter(task => task.status === filter)

  const statusColors = {
    pending: '#faad14',
    running: '#1890ff',
    completed: '#52c41a',
    failed: '#ff4d4f'
  }

  const statusLabels = {
    pending: '等待中',
    running: '运行中',
    completed: '已完成',
    failed: '失败'
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content tasks-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="tasks-modal-header">
          <h2 className="modal-title">解析任务列表</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        
        <div className="tasks-filter">
          <button 
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            全部 ({tasks.length})
          </button>
          <button 
            className={`filter-btn ${filter === 'pending' ? 'active' : ''}`}
            onClick={() => setFilter('pending')}
          >
            等待中 ({tasks.filter(t => t.status === 'pending').length})
          </button>
          <button 
            className={`filter-btn ${filter === 'running' ? 'active' : ''}`}
            onClick={() => setFilter('running')}
          >
            运行中 ({tasks.filter(t => t.status === 'running').length})
          </button>
          <button 
            className={`filter-btn ${filter === 'completed' ? 'active' : ''}`}
            onClick={() => setFilter('completed')}
          >
            已完成 ({tasks.filter(t => t.status === 'completed').length})
          </button>
          <button 
            className={`filter-btn ${filter === 'failed' ? 'active' : ''}`}
            onClick={() => setFilter('failed')}
          >
            失败 ({tasks.filter(t => t.status === 'failed').length})
          </button>
        </div>

        <div className="tasks-list">
          {filteredTasks.length === 0 ? (
            <div className="tasks-empty">暂无任务</div>
          ) : (
            filteredTasks.map(task => (
              <div key={task.id} className="task-item">
                <div className="task-header">
                  <div className="task-info">
                    <span className="task-name">{task.name}</span>
                    <span 
                      className="task-status" 
                      style={{ backgroundColor: statusColors[task.status] }}
                    >
                      {statusLabels[task.status]}
                    </span>
                  </div>
                  <span className="task-date">
                    {new Date(task.createdAt).toLocaleString('zh-CN')}
                  </span>
                </div>
                
                <div className="task-details">
                  <div className="task-detail-item">
                    <span className="task-detail-label">Canvas:</span>
                    <span>{task.canvasName}</span>
                  </div>
                  <div className="task-detail-item">
                    <span className="task-detail-label">局点:</span>
                    <span>{task.siteName}</span>
                  </div>
                  <div className="task-detail-item">
                    <span className="task-detail-label">NIC文件:</span>
                    <span>{task.nicFileCount} 个</span>
                  </div>
                </div>

                {task.status === 'running' && (
                  <div className="task-progress">
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${task.progress}%` }}
                      ></div>
                    </div>
                    <span className="progress-text">
                      {task.progressMessage || `${task.progress}%`}
                    </span>
                  </div>
                )}

                {task.status === 'failed' && (
                  <div className="task-error">
                    错误: {task.errorMessage}
                  </div>
                )}

                {task.status === 'completed' && (
                  <div className="task-success">
                    已完成 - 耗时 {Math.round(
                      (new Date(task.completedAt) - new Date(task.createdAt)) / 1000
                    )}秒
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}