import { createContext, useContext, useState, useCallback } from 'react'

const TaskContext = createContext()

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useState([
    {
      id: 1,
      name: '北京局点NIC解析',
      canvasName: '北京网络拓扑',
      siteId: 'site1',
      siteName: '北京局点',
      nicFileCount: 4,
      status: 'completed',
      progress: 100,
      createdAt: '2026-01-15T10:30:00.000Z',
      completedAt: '2026-01-15T10:35:00.000Z'
    },
    {
      id: 2,
      name: '上海局点NIC解析',
      canvasName: '上海数据中心',
      siteId: 'site2',
      siteName: '上海局点',
      nicFileCount: 3,
      status: 'running',
      progress: 65,
      progressMessage: '正在解析文件: SH-Datacenter-SW01.nic',
      createdAt: '2026-02-01T14:20:00.000Z'
    },
    {
      id: 3,
      name: '广州局点NIC解析',
      canvasName: '广州边缘网络',
      siteId: 'site3',
      siteName: '广州局点',
      nicFileCount: 3,
      status: 'pending',
      progress: 0,
      createdAt: '2026-02-02T09:15:00.000Z'
    },
    {
      id: 4,
      name: '深圳局点NIC解析',
      canvasName: '深圳安全域',
      siteId: 'site4',
      siteName: '深圳局点',
      nicFileCount: 2,
      status: 'failed',
      progress: 100,
      errorMessage: '文件格式错误: SZ-Load-Balancer.nic',
      createdAt: '2026-01-28T16:45:00.000Z',
      failedAt: '2026-01-28T16:47:00.000Z'
    }
  ])

  const addTask = useCallback((taskData) => {
    const newTask = {
      id: tasks.length + 1,
      name: `${taskData.canvasName} - NIC解析`,
      canvasName: taskData.canvasName,
      siteId: taskData.siteId,
      siteName: getSiteName(taskData.siteId),
      nicFileCount: taskData.nicFileIds.length,
      status: 'pending',
      progress: 0,
      createdAt: new Date().toISOString()
    }
    setTasks(prev => [newTask, ...prev])
    return newTask
  }, [tasks.length])

  const updateTask = useCallback((taskId, updates) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, ...updates } : task
    ))
  }, [])

  const deleteTask = useCallback((taskId) => {
    setTasks(prev => prev.filter(task => task.id !== taskId))
  }, [])

  return (
    <TaskContext.Provider value={{ tasks, addTask, updateTask, deleteTask }}>
      {children}
    </TaskContext.Provider>
  )
}

export function useTask() {
  return useContext(TaskContext)
}

function getSiteName(siteId) {
  const siteMap = {
    site1: '北京局点',
    site2: '上海局点',
    site3: '广州局点',
    site4: '深圳局点'
  }
  return siteMap[siteId] || siteId
}